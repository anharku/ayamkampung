<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Tambah Data</title>
</head>

<body>
<h2 align="center">Tambah Data</h2>
<div id="infoMessage"><?php echo $message;?></div>
<?php echo form_open("product/add");?>
	<table width="700" border="1" cellpadding="0" cellspacing="2" align="center">
		<tr>
			<td width="130" align="right" bgcolor="#FFFFFF">Nama Kandang: </td>
			<td><?php echo form_input($name);?></td>
		</tr>
		<tr>
			<td width="130" align="right" bgcolor="#FFFFFF">Jenis Ternak: </td>
			<td><?php echo form_input($description); ?></td>
		</tr>
		<tr>
			<td align="right" bgcolor="#FFFFFF">Tanggal Masuk:</td>
			<td><?php echo form_input($price); ?></td>
		</tr>
		<tr>
			<td align="right" bgcolor="#FFFFFF">Jumlah Populasi:</td>
			<td><?php echo form_input($picture); ?></td>
		</tr>
		<tr>
			<tr>
			<td align="right" bgcolor="#FFFFFF">Umur Masuk:</td>
			<td><?php echo form_input($umur); ?></td>
		</tr>
			<tr>
			<td align="right" bgcolor="#FFFFFF">Pic:</td>
			<td><?php echo form_input($pic); ?></td>
		</tr>
			<td align="right" bgcolor="#FFFFFF">&nbsp;</td>
			<td><?php echo form_submit('submit', 'Submit');?>
				<input type="button" name="btnBack" id="btnBack" value="Back" onclick="window.location.href='<?php echo base_url() ?>'" /></td>
		</tr>
	</table>
<?php echo form_close(); ?>
</body>
</html>
